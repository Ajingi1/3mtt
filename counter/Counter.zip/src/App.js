import  './App.css'
import Counter from './Counter'

function App() {
  return (
    <div className="App">
      <div className="content">
        <Counter />
      </div>
    </div>
  );
}

export default App;
