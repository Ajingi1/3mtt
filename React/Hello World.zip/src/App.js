import './App.css'


function App() {
  
  return (
    <div className="App">
     
      <div className="content">
       
        <h1>Hello World</h1>
      </div>
    </div>
  );
}

export default App;
