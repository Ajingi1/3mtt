const Home = () => {
    return(
        <div className="home">
            <h1>Homepage</h1>
        </div>
    );
}

export default Home;