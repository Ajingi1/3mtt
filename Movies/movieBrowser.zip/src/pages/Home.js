import { useState } from 'react';
import  searchMovies  from '../api/omdb';
import SearchBar from '../components/SearchBar';
import MovieList from '../components/MovieList';
import '../styles/Home.css';

const Home = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = async (term) => {
    setLoading(true);
    setError('');
    try {
      const data = await searchMovies(term);
      if (data.Response === 'True') {
        setMovies(data.Search);
      } else {
        setMovies([]);
        setError(data.Error);
      }
    } catch (err) {
      setError('Failed to fetch data');
    }
    setLoading(false);
  };

  return (
    <main>
      <div className='search-container'>
        <h1 className='logo-text'>Movie Browser</h1>
        <SearchBar onSearch={handleSearch} />
      </div>
      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}
      <MovieList movies={movies} />
    </main>
  );
}


export default Home;
