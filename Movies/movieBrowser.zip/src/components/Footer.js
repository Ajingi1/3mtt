const Footer = () => {
    return(
        <div className="footer">
            
        </div>
    );
}

export default Footer;